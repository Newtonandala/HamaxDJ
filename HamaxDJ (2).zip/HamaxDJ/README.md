# HamaxDJ

A VirtualDJ-style mixing app for Android. Landscape only, two decks, audio and video.

## What works in this first version (Phase 1)

- Two decks (A and B). Load any audio or video file from your phone with LOAD.
- Audio and video are treated the same: every track has sound, and tracks with pictures also show on the output screen.
- Play / pause, and CDJ-style CUE (tap while paused to set the cue point, tap while playing to jump back to it, hold on the cue point to preview).
- Pitch fader per deck with range button (6, 8, 10, 16, 50 percent). Double-tap the fader to reset. KEY LOCK keeps the pitch of the music steady while the speed changes.
- Jog wheel per deck: spins with the music, drag around it to scrub. Tap or drag the strip above it to jump anywhere in the track.
- Channel volume faders and a crossfader (constant-power audio blend). The video output dissolves from deck A's picture to deck B's picture as you slide across.

## Coming next

Phase 2: BPM detection, real SYNC, scrolling waveforms. Phase 3: EQ, filters, headphone cue. Phase 4: loops, hot cues, sampler, effects. Phase 5: video effects and external screen output. Phase 6: library browser and playlists.

## Build the APK

**Android Studio:** open this folder, wait for Gradle to sync, press Run (or Build > Build APK).

**No computer needed (GitHub):** create a new GitHub repository, upload this whole folder (keep the `.github` folder), then open the Actions tab and run "Build HamaxDJ APK". When it finishes, download `HamaxDJ-debug-apk` from the run and install the `app-debug.apk` inside.

**Command line:** `./gradlew assembleDebug`. The APK ends up in `app/build/outputs/apk/debug/`.

Requires Android 8.0 (API 26) or newer.
